const choices = document.querySelectorAll('.choice');
const userChoiceDisplay = document.getElementById('user-choice');
const computerChoiceDisplay = document.getElementById('computer-choice');
const winnerDisplay = document.getElementById('winner');
const historyBtn = document.getElementById('history-btn');
const resetBtn = document.getElementById('reset-btn');
const historyDiv = document.getElementById('history');
const historyList = document.getElementById('history-list');

let history = JSON.parse(localStorage.getItem('rps-history')) || [];

function getComputerChoice() {
  const options = ['rock', 'paper', 'scissors'];
  return options[Math.floor(Math.random() * 3)];
}

function getWinner(user, computer) {
  if (user === computer) return "It's a Draw!";
  if (
    (user === 'rock' && computer === 'scissors') ||
    (user === 'paper' && computer === 'rock') ||
    (user === 'scissors' && computer === 'paper')
  ) return "You Win!";
  return "Computer Wins!";
}

function playGame(userChoice) {
  const computerChoice = getComputerChoice();
  const result = getWinner(userChoice, computerChoice);

  userChoiceDisplay.textContent = `You chose: ${userChoice}`;
  computerChoiceDisplay.textContent = `Computer chose: ${computerChoice}`;
  winnerDisplay.textContent = result;

  // Save result to history
  const game = {
    user: userChoice,
    computer: computerChoice,
    result: result,
    time: new Date().toLocaleTimeString()
  };
  history.push(game);
  localStorage.setItem('rps-history', JSON.stringify(history));
}

choices.forEach(choice => {
  choice.addEventListener('click', e => {
    playGame(e.target.dataset.choice);
  });
});

historyBtn.addEventListener('click', () => {
  historyDiv.classList.toggle('hidden');
  historyList.innerHTML = '';
  history.forEach((item, index) => {
    const li = document.createElement('li');
    li.textContent = `Game ${index + 1}: You chose ${item.user}, Computer chose ${item.computer} → ${item.result} (${item.time})`;
    historyList.appendChild(li);
  });
});

resetBtn.addEventListener('click', () => {
  localStorage.removeItem('rps-history');
  history = [];
  historyList.innerHTML = '';
  userChoiceDisplay.textContent = '';
  computerChoiceDisplay.textContent = '';
  winnerDisplay.textContent = '';
  alert("Game has been reset!");
});
